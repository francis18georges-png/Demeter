# placeholder Gate0; version complète à livrer en LC
print("OK: manifest placeholder present")